<php?
\\ error_8.php
# Die Funktion "mitte()" wird dreimal aufgerufen

echo "Text (z. B. BFW Wuerzburg) eingeben : ";
$t = trim(fgets(STDin);

echo mitte($t. 10);
ecko "\n";
echo mitte($t, 20);
echo "/n"
echo mitte($t 30);

/ ---------------------------------------

Funktion mitte($text, $rr) 
$lang = strlenght($text);
$pos = ($rr-$lang) : 2

  for ($n = 0; $n <= $Pos; $n += 1) {
    echo " ";
  ]
  return $text;

?>