<?php
// zinsen_A.php

echo "Kapital  : ";
# Kapital eingeben  

echo "Zinssatz : ";
# Zinssatz eingeben 

echo "Tage     : ";
# Nur ganze Tage eingeben

# Tageszinsformel: Zinsertrag = Kapital * Zinssatz * Tage / (100 * 360);
# Zinsertrag ausrechnen

# Jetzt eine Zeilenschaltung


# hier steht die printf-Anweisung
# Muster: "Zinsertrag : 18.30 Euro"

?>