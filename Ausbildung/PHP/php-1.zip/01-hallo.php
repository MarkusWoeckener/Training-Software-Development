<?php
// 01-hallo.php
for ($x = 0; $x<10; $x++)
{
echo "Hallo Welt!\n";
}
?>