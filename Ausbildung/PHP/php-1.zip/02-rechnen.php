<?php
//02-rechnen.php

$a = 25.2; //Das ist eine Zuweisung
$b = 2;
$c = $a + $b;

echo $a." + ".$b." = ".$c;
?>