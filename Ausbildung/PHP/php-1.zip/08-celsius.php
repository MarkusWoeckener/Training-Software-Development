<?php
// celsius.php
// Programmieren Sie eine echo-Anweisung in Zeile 10

$c = 24;
$f = $c * 1.8 + 32; // Ergebnis = 75.2

// Auf dem Monitor soll stehen: 
// 24 Grad Celsius = 75.2 Grad Fahrenheit
echo $c." Grad Celsius = ".$f." Grad Fahrenheit\n";

?>