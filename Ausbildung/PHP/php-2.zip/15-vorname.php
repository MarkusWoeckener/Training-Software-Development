<?php
// vorname.php
/*
Name: Markus Woeckener
Datum: 30.04.24
+/

echo "Dein Vorname bitte : ";
$vorname = trim(fgets(STDIN));

printf("\nDer Name %s ist toll!\n", $vorname);

?>