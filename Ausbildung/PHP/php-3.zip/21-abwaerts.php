<?php
//21-abwaerts.php
/*
Name: Markus Woeckener
Datum: 30.04.24
*/

//Zählvariable definieren
$z = (int) 20;

while($z >= 0) //kopfgesteuerte Schleife
{
    printf("%2d\n", $z); //Ausgabe des Wertes Von $z
    $z--; //Dekrement
}

?>