<?php
// chr_2.php

for ($n = 0; $n <= 300; $n++) 
{
	printf("Position %3d = %c\n", $n, $n);
}    

?>