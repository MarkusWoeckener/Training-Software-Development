<?php
// loop3.php
// drei identische Schleifen

for ($n = 0; $n <= 30; $n++) 
{
	echo "-";
}
	
echo "\n";

// -----------------------------

for ($n = 0; $n <= 30; $n++) 
{
	echo "-";
}

echo "\n";

// -----------------------------

for ($n = 0; $n <= 30; $n++) 
{
	echo "-";
}

echo "\n";

?>