<?php
// strafe_3.php

$satz = "Ich darf nicht petzen";

  for ($z = 1; $z <= 100; $z++) {
    printf("%2d. %s\n", $z, $satz);
  }

?>