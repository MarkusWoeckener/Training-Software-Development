<?php
// vorname.php

echo "Dein Vorname bitte : ";
$vorname = fgets(STDIN);

printf("\nDer Name %s ist toll!\n", $vorname);

?>