<?php
// zaehlen_2.php
// do while-Schleife

$zahl  = NULL;

do 
{
	$zahl += 1;
	echo $zahl." ";
} 
while ($zahl < 10);

echo "\n";

?>