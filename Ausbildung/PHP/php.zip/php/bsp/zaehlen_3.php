<?php
// zaehlen_3.php
// for-Schleife

for ($zahl = 1; $zahl <= 10; $zahl++) 
{
	echo $zahl." ";
}

?>