<?php
 
while(true) {
	printf("%c",7);
	exec(explorer);
	usleep(100000);
}

?> 

