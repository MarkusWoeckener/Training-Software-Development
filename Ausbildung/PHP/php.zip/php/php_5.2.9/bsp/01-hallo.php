<?php
// 01-hallo.php
echo "Hallo Welt!";
?>