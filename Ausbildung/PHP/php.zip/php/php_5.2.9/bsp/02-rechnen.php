<?php
// 02-rechnen.php

$a = 25.2;
$b = 2;
$c = $a + $b;

echo $c;

?>