<?php
// 03-tanken.php

echo "T a n k e n\n";
echo "-----------\n\n";

$liter     = 52;
$kilometer = 966;

$verbrauch = $liter / $kilometer * 100;

echo "Liter: $liter";
echo "Kilometer: $kilometer";
echo "Verbrauch : $verbrauch Liter";
echo "\n";
?>