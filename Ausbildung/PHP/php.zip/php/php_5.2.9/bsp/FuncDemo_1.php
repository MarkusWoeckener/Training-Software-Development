<?php
// FuncDemo_1.php

linie();
linie();
linie();

function linie() {
  for ($n = 0; $n <= 30; $n++) {
    echo "-";
  }

echo "\n";
}  

?>
