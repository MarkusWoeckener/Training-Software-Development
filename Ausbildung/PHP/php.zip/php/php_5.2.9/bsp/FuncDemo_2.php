<?php
// FuncDemo_2.php

echo "BFW\n";
linie();
linie();

// ---------------------------------

function linie() {
  for ($n = 0; $n <= 30; $n++) {
    echo "-";
    pause();
  }

echo "\n";
}  

// ---------------------------------

function pause() {
$tempo = 250000;

  for ($z = 0; $z <= $tempo; $z++) {
  }
}

?>
