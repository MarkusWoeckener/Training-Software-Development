<?php
// chr_1.php

$pos = 97;

echo chr($pos)."\n";
printf("Der Nachfolger ist ein %c\n", $pos + 1);

?>
