<?php
// chr_2.php

  for ($n = 97; $n <= 122; $n++) {
     printf("Position %3d = %c\n", $n, $n);
  }    

?> 

