<?php
// gauss.php

$summe = NULL;

  for ($zahl = 1; $zahl <= 100; $zahl++) {
    $summe = $summe + $zahl;

    
    # "Pause" einbauen

  }

echo "Summe der Zahlen bis 100 : ".$summe; 
echo "\n";

?>
