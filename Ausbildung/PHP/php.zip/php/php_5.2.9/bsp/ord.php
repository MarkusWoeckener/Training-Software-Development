<?php
// ord_1.php

$zchn = "P";
echo ord($zchn)."\n";

?>
