<?php
// rechnung.php
// Ergaenzen Sie das Programm an den Fragezeichen

$versand = 8;
$porto   = 3;

$rechnung = NULL; // Rechnungsbetrag
$total    = NULL; // Das muss bezahlt werden

echo "Rechnungsbetrag    : ";
?

  if ($rechnung ?)
    $total = ? + ? + ?

  else
  if ($rechnung ?)
    ? = ? + ?
  
  ?
    $total = ?

// Hier die Meldung mit zwei Nachkommastellen:
// "Bitte bezahlen Sie : ? Euro\n"

?>
