<?php
// strafe_1.php
// while-Schleife

$satz = "Ich darf nicht petzen";
$n    = 1;

  while ($n < 10) {
     printf("%2d. %s\n", $n, $satz);
     $n++;
  }
?>
