<?php
// zaehlen_1.php
// while-Schleife

$zahl = NULL;

   while ($zahl < 10) {
      $zahl = $zahl + 1;
      echo $zahl." ";
   }

echo "\n";

?>
